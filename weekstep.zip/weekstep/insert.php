<?php
	include_once "header.php";
?>


	<div>
  	<div class="container topSpace">
        <div class="row">
          <div class="col">
          </div>
          <div class="col-md-auto">
      			<h1 class="">What do you want to succeed this week?</h1>
          </div>
          <div class="col">

          </div>
        </div>
    </div>

    <div class="row">
      <div class="col">
      </div>
      <div class="col-md-auto">
        <form class="" action="" method="">
          <div class="form-group">
             <label for="exampleFormControlTextarea1">Insert goals here</label>
             <textarea class="form-control areaEdit" id="exampleFormControlTextarea1" rows="8"></textarea>
             <button class="buttonClass" type="button" name="button">Send</button>
          </div>
        </form>
      </div>
      <div class="col">

      </div>
    </div>


</div>

<?php
	include_once "footer.php";
?>
