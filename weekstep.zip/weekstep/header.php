<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/css/main.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="assets/css/style2.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        		<!-- jQuery CDN - Slim version (=without AJAX) -->
        		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        		<!-- Popper.JS -->
        		<!-- Bootstrap JS -->
        		<!-- jQuery Custom Scroller CDN -->
        		<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

        		<script type="text/javascript">
        				$(document).ready(function () {
        						$("#sidebar").mCustomScrollbar({
        								theme: "minimal"
        						});

        						$('#sidebarCollapse').on('click', function () {
        								$('#sidebar, #content').toggleClass('active');
        								$('.collapse.in').toggleClass('in');
        								$('a[aria-expanded=true]').attr('aria-expanded', 'false');
        						});
        				});
        		</script>

            <!--  Calendar Script -->

            <script type="text/javascript">


              var today = new Date();
            var currentMonth = today.getMonth();
            var currentYear = today.getFullYear();
            var selectYear = document.getElementById("year");
            var selectMonth = document.getElementById("month");

            var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

            var monthAndYear = document.getElementById("monthAndYear");
            showCalendar(currentMonth, currentYear);


            function next() {
                currentYear = (currentMonth === 11) ? currentYear + 1 : currentYear;
                currentMonth = (currentMonth + 1) % 12;
                showCalendar(currentMonth, currentYear);
            }

            function previous() {
                currentYear = (currentMonth === 0) ? currentYear - 1 : currentYear;
                currentMonth = (currentMonth === 0) ? 11 : currentMonth - 1;
                showCalendar(currentMonth, currentYear);
            }

            function jump() {
                currentYear = parseInt(selectYear.value);
                currentMonth = parseInt(selectMonth.value);
                showCalendar(currentMonth, currentYear);
            }

            function showCalendar(month, year) {

                var firstDay = (new Date(year, month)).getDay();
                var daysInMonth = 32 - new Date(year, month, 32).getDate();

                var tbl = document.getElementById("calendar-body"); // body of the calendar

                // clearing all previous cells

                tbl.innerHTML = "";

                // filing data about month and in the page via DOM.
                monthAndYear.innerHTML = months[month] + " " + year;
                selectYear.value = year;
                selectMonth.value = month;

                // creating all cells
                var date = 1;
                for (var i = 0; i < 6; i++) {
                    // creates a table row
                    var row = document.createElement("tr");

                    //creating individual cells, filing them up with data.
                    for (var j = 0; j < 7; j++) {
                        if (i === 0 && j < firstDay) {
                            var cell = document.createElement("td");
                            var cellText = document.createTextNode("");
                            cell.appendChild(cellText);
                            row.appendChild(cell);
                        }
                        else if (date > daysInMonth) {
                            break;
                        }

                        else {
                            var cell = document.createElement("td");
                            var cellText = document.createTextNode(date);
                            if (date === today.getDate() && year === today.getFullYear() && month === today.getMonth()) {
                                cell.classList.add("bg-info");
                            } // color today's date
                            cell.appendChild(cellText);
                            row.appendChild(cell);
                            date++;
                        }


                    }

                    tbl.appendChild(row); // appending each row into calendar body.
                }

            }


            </script>

            <!-- End of Calendar Script -->


    <script type="text/javascript" src="assets/js/main.js"></script>

    <title>WEEKSTEP</title>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">

</nav>
  </head>
  <body>
