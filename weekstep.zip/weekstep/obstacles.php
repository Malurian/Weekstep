<?php
	include_once "header.php";
?>


<div class="wrapper">
		<!-- Sidebar  -->
		<nav id="sidebar">
				<div class="sidebar-header">
						<h3 class="logoStyling">WEEKSTEP</h3>
						<h3 class="paragraph-style">Self-Coaching</h3>
				</div>


				<!-- <ul class="list-unstyled components">
						<p>Dummy Heading</p>
						<li class="active">
								<a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
								<ul class="collapse list-unstyled" id="homeSubmenu">
										<li>
												<a href="#">Home 1</a>
										</li>
										<li>
												<a href="#">Home 2</a>
										</li>
										<li>
												<a href="#">Home 3</a>
										</li>
								</ul>
						</li>
						<li>
								<a href="#">About</a>
						</li>
						<li>
								<a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
								<ul class="collapse list-unstyled" id="pageSubmenu">
										<li>
												<a href="#">Page 1</a>
										</li>
										<li>
												<a href="#">Page 2</a>
										</li>
										<li>
												<a href="#">Page 3</a>
										</li>
								</ul>
						</li>
						<li>
								<a href="#">Portfolio</a>
						</li>
						<li>
								<a href="#">Contact</a>
						</li>
				</ul> -->

				<!-- <ul class="list-unstyled CTAs">
						<li>
								<a href="https://bootstrapious.com/tutorial/files/sidebar.zip" class="download">Download source</a>
						</li>
						<li>
								<a href="https://bootstrapious.com/p/bootstrap-sidebar" class="article">Back to article</a>
						</li>
				</ul> -->
		</nav>

		<!-- Page Content  -->
		<div id="content">

				<nav class="navbar navbar-expand-lg navbar-light bg-light">
						<div class="container-fluid">

								<button type="button" id="sidebarCollapse" class="btn btn-info">
										<i class="fas fa-align-left"></i>
										<span>Toggle Sidebar</span>
								</button>
								<!-- <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
										<i class="fas fa-align-justify"></i>
								</button> -->

								<!-- <div class="collapse navbar-collapse" id="navbarSupportedContent">
										<ul class="nav navbar-nav ml-auto">
												<li class="nav-item active">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
										</ul>
								</div> -->
								<div class="listAlign">
									<a href="confidence.php">
								<button type="button" class="btn btn-outline-primary">Confidence & Joy</button>
									</a>
									<a href="obstacles.php">
								<button type="button" class="btn btn-outline-secondary">Obstacles & Challenges</button>
									</a>
								<a href="objectives.php">
								<button type="button" class="btn btn-outline-success">Objestives for today</button>
									</a>
										<!-- <a href="objectives.php">
								<button type="button" class="btn btn-outline-danger">Objectives</button>
									</a> -->

							</div>

						</div>
				</nav>
				<div class="container topSpace">
						<div class="row">
							<div class="col">

							</div>
							<div class="col-md-auto">
								<h1 class="">What makes you feel grateful today?</h1>
							</div>
							<div class="col">

							</div>
						</div>
				</div>


								<div class="container-fluid">

									<div class="container">
										<div class="row space-top">
											<div class="col-sm">
												<div class="card bg-light mb-3" style="max-width: 18rem;">
													<div class="card-header">First</div>
													<div class="card-body">
														<h5 class="card-title">Light card title</h5>
														<p class="card-text">I like Stockholddesign’s design.</p>
													</div>
												</div>
											</div>
											<div class="col-sm">
												<div class="text-center">
  												<img src="assets/img/arrow.png" id="simple-image" class="rounded" alt="arrow">
												</div>
											</div>
												<div class="col-sm">
													<div class="card bg-light mb-3" style="max-width: 18rem;">
														<div class="card-header">Second</div>
														<div class="card-body">
															<h5 class="card-title">Light card title</h5>
															<p class="card-text">I have a good vision of the application.</p>
														</div>
													</div>
													<div class="progress">
														<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
													</div>
												</div>
											</div>
									</div>
								</div>

								<div class="container-fluid">

									<div class="container">
										<div class="row space-top">
											<div class="col-sm">
												<div class="card bg-light mb-3" style="max-width: 18rem;">
													<div class="card-header">Fourth</div>
													<div class="card-body">
														<h5 class="card-title">Light card title</h5>
														<p class="card-text">Camille wants to self-coach. What  joy to have a 8 years old pilot user!.</p>
													</div>
												</div>
											</div>
											<div class="col-sm">
												<div class="text-center">
  												<img src="assets/img/arrow.png" id="simple-image" class="rounded" alt="arrow">
												</div>
											</div>
												<div class="col-sm">
													<div class="card bg-light mb-3" style="max-width: 18rem;">
														<div class="card-header">Sixth</div>
														<div class="card-body">
															<h5 class="card-title">Light card title</h5>
															<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
														</div>
													</div>
													<div class="progress">
														<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
													</div>
												</div>
											</div>
									</div>
								</div>

				<div class="footer_section">

					<div class="container topSpace">
					<div class="row">
						<div class="col">
						</div>
						<div class="col-md-auto">
							<div class="col">
								<p id="dateClass"></p>
							</div>
						</div>
						<div class="col">
						</div>
					</div>
				</div>
		</div>


</div>


	<!-- <div class="container topSpace">
			<div class="row">
				<div class="col">

				</div>
				<div class="col-md-auto">
					<h1 class="">Your exciting goals for this week</h1>
				</div>
				<div class="col">

				</div>
			</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
					<div class="card-header">First</div>
					<div class="card-body">
						<h5 class="card-title">Primary card title</h5>
						<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
					</div>
				</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
						  <div class="card-header">Second</div>
						  <div class="card-body">
						    <h5 class="card-title">Secondary card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-success mb-3" style="max-width: 18rem;">
						  <div class="card-header">Third</div>
						  <div class="card-body">
						    <h5 class="card-title">Success card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
				</div>
		</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
					  <div class="card-header">Fourth</div>
					  <div class="card-body">
					    <h5 class="card-title">Warning card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
					  </div>
					</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
						  <div class="card-header">Fifth</div>
						  <div class="card-body">
						    <h5 class="card-title">Danger card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-info mb-3" style="max-width: 18rem;">
						  <div class="card-header">Sixth</div>
						  <div class="card-body">
						    <h5 class="card-title">Info card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
				</div>
		</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
						<div class="card-header">Seventh</div>
						<div class="card-body">
							<h5 class="card-title">Secondary card title</h5>
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						</div>
					</div>
					</div>
					<div class="col-sm">
						<div class="card bg-light mb-3" style="max-width: 18rem;">
						  <div class="card-header">Eighth</div>
						  <div class="card-body">
						    <h5 class="card-title">Light card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card bg-success mb-3" style="max-width: 18rem;">
							<div class="card-header">Ninth</div>
							<div class="card-body">
								<h5 class="card-title">Success card title</h5>
								<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
							</div>
						</div>
					</div>
				</div>
		</div>
	</div> -->


<!-- <div class="card-group">
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
</div> -->

	<!--
	<div>
	<div class="container topSpace">
  <div class="row">
    <div class="col">
    </div>
    <div class="col-md-auto">
			<h1 class="">What do you want to succeed this week?</h1>
    </div>
    <div class="col">

    </div>
  </div>
</div>

<div class="centerContainer">
	<input type="textarea">
	<button type="button" name="button">Send</button>
</div>
</div>

<div class="row space-top">
	<div class="col-sm column-Settings">
		One of three columns
	</div>
	<div class="col-sm column-Settings">
		One of three columns
	</div>
	<div class="col-sm column-Settings">
		One of three columns
	</div>
</div> -->
