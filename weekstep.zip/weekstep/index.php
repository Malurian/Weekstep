<?php
	include_once "header.php";
?>


<div class="wrapper">
		<!-- Sidebar  -->
		<nav id="sidebar">
				<div class="sidebar-header">
						<h3 class="logoStyling">WEEKSTEP</h3>
						<h3 class="paragraph-style">Self-Coaching</h3>
				</div>

				<div class="row">


				<div class="container">
						<div class="card">
								<h3 class="card-header" id="monthAndYear"></h3>
								<table class="table table-bordered table-responsive-sm" id="calendar">
										<thead>
										<tr>
												<th>Sun</th>
												<th>Mon</th>
												<th>Tue</th>
												<th>Wed</th>
												<th>Thu</th>
												<th>Fri</th>
												<th>Sat</th>
										</tr>
										</thead>

										<tbody id="calendar-body">

										</tbody>
								</table>

								<div class="form-inline">

										<button class="btn btn-outline-primary col-sm-6" id="previous" onclick="previous()">Previous</button>

										<button class="btn btn-outline-primary col-sm-6" id="next" onclick="next()">Next</button>
								</div>
								<br/>
								<form class="form-inline">
										<label class="lead mr-2 ml-2" for="month">Jump To: </label>
										<select class="form-control col-sm-4" name="month" id="month" onchange="jump()">
												<option value=0>Jan</option>
												<option value=1>Feb</option>
												<option value=2>Mar</option>
												<option value=3>Apr</option>
												<option value=4>May</option>
												<option value=5>Jun</option>
												<option value=6>Jul</option>
												<option value=7>Aug</option>
												<option value=8>Sep</option>
												<option value=9>Oct</option>
												<option value=10>Nov</option>
												<option value=11>Dec</option>
										</select>


										<label for="year"></label><select class="form-control col-sm-4" name="year" id="year" onchange="jump()">
										<option value=1990>1990</option>
										<option value=1991>1991</option>
										<option value=1992>1992</option>
										<option value=1993>1993</option>
										<option value=1994>1994</option>
										<option value=1995>1995</option>
										<option value=1996>1996</option>
										<option value=1997>1997</option>
										<option value=1998>1998</option>
										<option value=1999>1999</option>
										<option value=2000>2000</option>
										<option value=2001>2001</option>
										<option value=2002>2002</option>
										<option value=2003>2003</option>
										<option value=2004>2004</option>
										<option value=2005>2005</option>
										<option value=2006>2006</option>
										<option value=2007>2007</option>
										<option value=2008>2008</option>
										<option value=2009>2009</option>
										<option value=2010>2010</option>
										<option value=2011>2011</option>
										<option value=2012>2012</option>
										<option value=2013>2013</option>
										<option value=2014>2014</option>
										<option value=2015>2015</option>
										<option value=2016>2016</option>
										<option value=2017>2017</option>
										<option value=2018>2018</option>
										<option value=2019>2019</option>
										<option value=2020>2020</option>
										<option value=2021>2021</option>
										<option value=2022>2022</option>
										<option value=2023>2023</option>
										<option value=2024>2024</option>
										<option value=2025>2025</option>
										<option value=2026>2026</option>
										<option value=2027>2027</option>
										<option value=2028>2028</option>
										<option value=2029>2029</option>
										<option value=2030>2030</option>
								</select></form>
						</div>
				</div>

				</div>
				<!-- <ul class="list-unstyled components">
						<p>Dummy Heading</p>
						<li class="active">
								<a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
								<ul class="collapse list-unstyled" id="homeSubmenu">
										<li>
												<a href="#">Home 1</a>
										</li>
										<li>
												<a href="#">Home 2</a>
										</li>
										<li>
												<a href="#">Home 3</a>
										</li>
								</ul>
						</li>
						<li>
								<a href="#">About</a>
						</li>
						<li>
								<a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
								<ul class="collapse list-unstyled" id="pageSubmenu">
										<li>
												<a href="#">Page 1</a>
										</li>
										<li>
												<a href="#">Page 2</a>
										</li>
										<li>
												<a href="#">Page 3</a>
										</li>
								</ul>
						</li>
						<li>
								<a href="#">Portfolio</a>
						</li>
						<li>
								<a href="#">Contact</a>
						</li>
				</ul> -->

				<!-- <ul class="list-unstyled CTAs">
						<li>
								<a href="https://bootstrapious.com/tutorial/files/sidebar.zip" class="download">Download source</a>
						</li>
						<li>
								<a href="https://bootstrapious.com/p/bootstrap-sidebar" class="article">Back to article</a>
						</li>
				</ul> -->
		</nav>

		<!-- Page Content  -->
		<div id="content">

				<nav class="navbar navbar-expand-lg navbar-light bg-light">
						<div class="container-fluid">

								<button type="button" id="sidebarCollapse" class="btn btn-info">
										<i class="fas fa-align-left"></i>
										<span>Toggle Sidebar</span>
								</button>
								<!-- <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
										<i class="fas fa-align-justify"></i>
								</button> -->

								<!-- <div class="collapse navbar-collapse" id="navbarSupportedContent">
										<ul class="nav navbar-nav ml-auto">
												<li class="nav-item active">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
												<li class="nav-item">
														<a class="nav-link" href="#">Page</a>
												</li>
										</ul>
								</div> -->
								<div class="listAlign">
									<a href="index.php">
								<button type="button" class="btn btn-outline-primary">HOW?</button>
									</a>
									<a href="successes.php">
								<button type="button" class="btn btn-outline-secondary">WHY?</button>
									</a>
									<!-- <a href="obstacles.php">
								<button type="button" class="btn btn-outline-success">Obstacles</button>
									</a>
									<a href="objectives.php">
								<button type="button" class="btn btn-outline-danger">Objectives</button>
									</a> -->

							</div>

						</div>
				</nav>
				<div class="container topSpace">
						<div class="row">
							<div class="col">

							</div>
							<div class="col-md-auto">
								<h1 class="">How will you succeed this week?</h1>
							</div>
							<div class="col">

							</div>
						</div>
				</div>





				<div class="container-fluid">

					<div class="container">
						<div class="row space-top">
							<div class="col-sm">
								<div class="card bg-light mb-3" style="max-width: 18rem;">
									<div class="card-header">First</div>
									<div class="card-body">
										<h5 class="card-title">Light card title</h5>
										<p class="card-text">I achieve an awesome design for weekstep.</p>
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
								</div>
							</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Second</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">I beat my best friend in bowling by at least 40 points.</p>
										</div>
									</div>
									<div class="progress">
										<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Third</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">I love living in Stockholm in the spring.</p>
										</div>
									</div>
									<div class="progress">
										<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
							</div>
					</div>
				</div>

				<div class="container-fluid">

					<div class="container">
						<div class="row space-top">
							<div class="col-sm">
								<div class="card bg-light mb-3" style="max-width: 18rem;">
									<div class="card-header">Fourth</div>
									<div class="card-body">
										<h5 class="card-title">Light card title</h5>
										<p class="card-text">A fourth goal that is really challenging.</p>
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
								</div>
							</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Fifth</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">a goal that wil make you progress and feel confidence and joy this week.</p>
										</div>
									</div>
									<div class="progress">
										<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Sixth</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
										</div>
									</div>
									<div class="progress">
										<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
							</div>
					</div>
				</div>

				<div class="container-fluid">

					<div class="container">
						<div class="row space-top">
							<div class="col-sm">
								<div class="card bg-light mb-3" style="max-width: 18rem;">
									<div class="card-header">Seventh</div>
									<div class="card-body">
										<h5 class="card-title">Light card title</h5>
										<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
									</div>
								</div>
								<div class="progress">
									<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
								</div>
							</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Eighth</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
										</div>
									</div>
									<div class="progress">
										<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
								<div class="col-sm">
									<div class="card bg-light mb-3" style="max-width: 18rem;">
										<div class="card-header">Ninth</div>
										<div class="card-body">
											<h5 class="card-title">Light card title</h5>
											<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
										</div>
									</div>
									<div class="progress">
	  								<div class="progress-bar bg-info" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
									</div>
								</div>
							</div>
					</div>
				</div>



				<div class="footer_section">

					<div class="container topSpace">
					<div class="row">
						<div class="col">
						</div>
						<div class="col-md-auto">
							<div class="col">
								<p id="dateClass"></p>
							</div>
						</div>
						<div class="col">
						</div>
					</div>
				</div>
		</div>


</div>


	<!-- <div class="container topSpace">
			<div class="row">
				<div class="col">

				</div>
				<div class="col-md-auto">
					<h1 class="">Your exciting goals for this week</h1>
				</div>
				<div class="col">

				</div>
			</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-primary mb-3" style="max-width: 18rem;">
					<div class="card-header">First</div>
					<div class="card-body">
						<h5 class="card-title">Primary card title</h5>
						<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
					</div>
				</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
						  <div class="card-header">Second</div>
						  <div class="card-body">
						    <h5 class="card-title">Secondary card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-success mb-3" style="max-width: 18rem;">
						  <div class="card-header">Third</div>
						  <div class="card-body">
						    <h5 class="card-title">Success card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
				</div>
		</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-warning mb-3" style="max-width: 18rem;">
					  <div class="card-header">Fourth</div>
					  <div class="card-body">
					    <h5 class="card-title">Warning card title</h5>
					    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
					  </div>
					</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-danger mb-3" style="max-width: 18rem;">
						  <div class="card-header">Fifth</div>
						  <div class="card-body">
						    <h5 class="card-title">Danger card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card text-white bg-info mb-3" style="max-width: 18rem;">
						  <div class="card-header">Sixth</div>
						  <div class="card-body">
						    <h5 class="card-title">Info card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
				</div>
		</div>
	</div>

	<div class="container-fluid">

		<div class="container">
			<div class="row space-top">
				<div class="col-sm">
					<div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
						<div class="card-header">Seventh</div>
						<div class="card-body">
							<h5 class="card-title">Secondary card title</h5>
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						</div>
					</div>
					</div>
					<div class="col-sm">
						<div class="card bg-light mb-3" style="max-width: 18rem;">
						  <div class="card-header">Eighth</div>
						  <div class="card-body">
						    <h5 class="card-title">Light card title</h5>
						    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
						  </div>
						</div>
					</div>
					<div class="col-sm">
						<div class="card bg-success mb-3" style="max-width: 18rem;">
							<div class="card-header">Ninth</div>
							<div class="card-body">
								<h5 class="card-title">Success card title</h5>
								<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
							</div>
						</div>
					</div>
				</div>
		</div>
	</div> -->


<!-- <div class="card-group">
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    <img src="..." class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">Card title</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
</div> -->

	<!--
	<div>
	<div class="container topSpace">
  <div class="row">
    <div class="col">
    </div>
    <div class="col-md-auto">
			<h1 class="">What do you want to succeed this week?</h1>
    </div>
    <div class="col">

    </div>
  </div>
</div>

<div class="centerContainer">
	<input type="textarea">
	<button type="button" name="button">Send</button>
</div>
</div>

<div class="row space-top">
	<div class="col-sm column-Settings">
		One of three columns
	</div>
	<div class="col-sm column-Settings">
		One of three columns
	</div>
	<div class="col-sm column-Settings">
		One of three columns
	</div>
</div> -->
